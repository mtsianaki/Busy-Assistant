#!/usr/bin/env bash
set -euo pipefail

VERSION="1.0.0"
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DB="/opt/busy-assistant/data/busy.db"
MENU_DB="/var/www/db/menu.db"
ACL_DB="/var/www/db/acl.db"
BACKUP_DIR="/root/busy-assistant-backup-$(date +%Y%m%d-%H%M%S)"
AGI_DIR="/var/lib/asterisk/agi-bin/busy-assistant"
WEB_DIR="/var/www/html/modules"

say(){ printf '\n[Busy Assistant] %s\n' "$*"; }
fail(){ printf '\nERROR: %s\n' "$*" >&2; exit 1; }

[[ ${EUID:-$(id -u)} -eq 0 ]] || fail "Run this installer as root."

PKG_MGR=""
command -v dnf >/dev/null 2>&1 && PKG_MGR="dnf"
[[ -z "$PKG_MGR" ]] && command -v yum >/dev/null 2>&1 && PKG_MGR="yum"

if ! command -v python3 >/dev/null 2>&1; then
    [[ -n "$PKG_MGR" ]] || fail "python3 is missing and no dnf/yum package manager is available."
    "$PKG_MGR" -y install python3
fi
if ! command -v sqlite3 >/dev/null 2>&1; then
    [[ -n "$PKG_MGR" ]] || fail "sqlite3 is missing and no dnf/yum package manager is available."
    "$PKG_MGR" -y install sqlite
fi
command -v asterisk >/dev/null 2>&1 || fail "Asterisk CLI not found. Install this package on an Issabel/Asterisk server."
if command -v php >/dev/null 2>&1; then
    if ! php -r 'exit(class_exists("SQLite3") ? 0 : 1);'; then
        [[ -n "$PKG_MGR" ]] || fail "PHP SQLite3 extension is missing."
        "$PKG_MGR" -y install php-sqlite3 || fail "Could not install PHP SQLite3 extension."
    fi
else
    fail "PHP not found. This installer requires the Issabel web stack."
fi
[[ -d /var/www/html/modules ]] || fail "Issabel module directory not found: /var/www/html/modules"
[[ -f "$MENU_DB" ]] || fail "Issabel menu database not found: $MENU_DB"
[[ -f "$ACL_DB" ]] || fail "Issabel ACL database not found: $ACL_DB"

say "Creating backup at $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
for p in /opt/busy-assistant "$AGI_DIR" \
         "$WEB_DIR/busy_assistant" "$WEB_DIR/busy_dashboard" "$WEB_DIR/busy_extensions" "$WEB_DIR/busy_calls" "$WEB_DIR/busy_audio" "$WEB_DIR/busy_bale" "$WEB_DIR/busy_settings" \
         /etc/asterisk/extensions_override_issabel.conf /etc/asterisk/extensions_custom.conf /etc/asterisk/queues_custom.conf "$MENU_DB" "$ACL_DB"; do
    if [[ -e "$p" ]]; then
        n="$(echo "$p" | sed 's#^/##; s#/#__#g')"
        cp -a "$p" "$BACKUP_DIR/$n"
    fi
done

say "Creating directories"
mkdir -p /opt/busy-assistant/{data,logs} "$AGI_DIR" /var/lib/asterisk/sounds/custom
touch /opt/busy-assistant/logs/busy-assistant.log

say "Installing database schema"
sqlite3 "$DB" < "$BASE_DIR/db/schema.sql"

printf "Bale bot token (press Enter to configure later in the web panel): "
IFS= read -r -s BALE_TOKEN || true
printf '\n'
printf "Admin Bale chat IDs (optional, comma or newline separated; press Enter to skip): "
IFS= read -r ADMIN_IDS || true
printf "Default queue timeout in seconds [180]: "
IFS= read -r DEFAULT_TIMEOUT || true
DEFAULT_TIMEOUT="${DEFAULT_TIMEOUT:-180}"
[[ "$DEFAULT_TIMEOUT" =~ ^[0-9]+$ ]] || DEFAULT_TIMEOUT=180

sql_q(){ printf "%s" "$1" | sed "s/'/''/g"; }
if [[ -n "${BALE_TOKEN:-}" ]]; then sqlite3 "$DB" "UPDATE settings SET value='$(sql_q "$BALE_TOKEN")',updated_at=datetime('now') WHERE key='bale_token';"; fi
if [[ -n "${ADMIN_IDS:-}" ]]; then sqlite3 "$DB" "UPDATE settings SET value='$(sql_q "$ADMIN_IDS")',updated_at=datetime('now') WHERE key='admin_chat_ids';"; fi
sqlite3 "$DB" "UPDATE settings SET value='$(sql_q "$DEFAULT_TIMEOUT")',updated_at=datetime('now') WHERE key='default_timeout';"
unset BALE_TOKEN || true

say "Installing AGI scripts and sync utility"
install -m 0755 "$BASE_DIR/agi/busy_assistant.py" "$AGI_DIR/busy_assistant.py"
install -m 0755 "$BASE_DIR/agi/misscall_engine.py" "$AGI_DIR/misscall_engine.py"
install -m 0755 "$BASE_DIR/tools/sync_extensions.py" /usr/local/sbin/busy-assistant-sync

say "Installing Issabel web modules"
for m in busy_assistant busy_dashboard busy_extensions busy_calls busy_audio busy_bale busy_settings; do
    rm -rf "$WEB_DIR/$m"
    cp -a "$BASE_DIR/web/modules/$m" "$WEB_DIR/$m"
done

# Ownership: Issabel/Asterisk commonly uses the asterisk account for both telephony and web writes.
chown -R asterisk:asterisk /opt/busy-assistant "$AGI_DIR" /var/lib/asterisk/sounds/custom
chmod 0775 /opt/busy-assistant/data /opt/busy-assistant/logs /var/lib/asterisk/sounds/custom
chmod 0664 "$DB" /opt/busy-assistant/logs/busy-assistant.log
find "$WEB_DIR/busy_assistant" "$WEB_DIR/busy_dashboard" "$WEB_DIR/busy_extensions" "$WEB_DIR/busy_calls" "$WEB_DIR/busy_audio" "$WEB_DIR/busy_bale" "$WEB_DIR/busy_settings" -type d -exec chmod 0755 {} +
find "$WEB_DIR/busy_assistant" "$WEB_DIR/busy_dashboard" "$WEB_DIR/busy_extensions" "$WEB_DIR/busy_calls" "$WEB_DIR/busy_audio" "$WEB_DIR/busy_bale" "$WEB_DIR/busy_settings" -type f -exec chmod 0644 {} +

replace_block(){
    local file="$1" block="$2" begin='; BEGIN BUSY_ASSISTANT_INSTALLER' end='; END BUSY_ASSISTANT_INSTALLER'
    touch "$file"
    python3 - "$file" "$block" "$begin" "$end" <<'PYBLOCK'
from pathlib import Path
import re,sys
f=Path(sys.argv[1]); b=Path(sys.argv[2]).read_text(encoding='utf-8'); begin=sys.argv[3]; end=sys.argv[4]
t=f.read_text(encoding='utf-8',errors='ignore') if f.exists() else ''
t=re.sub(re.escape(begin)+r'.*?'+re.escape(end)+r'\n?', '', t, flags=re.S).rstrip()+"\n\n"+b.rstrip()+"\n"
f.write_text(t,encoding='utf-8')
PYBLOCK
}

say "Installing Asterisk dialplan hooks"
replace_block /etc/asterisk/extensions_override_issabel.conf "$BASE_DIR/dialplan/extensions_override.block"
replace_block /etc/asterisk/extensions_custom.conf "$BASE_DIR/dialplan/extensions_custom.block"

say "Registering Issabel menus"
PARENT="pbxconfig"
[[ -n "$(sqlite3 "$MENU_DB" "SELECT id FROM menu WHERE id='pbxconfig' LIMIT 1;" 2>/dev/null)" ]] || PARENT=""
for id in busy_settings busy_bale busy_audio busy_calls busy_extensions busy_dashboard busy_assistant; do sqlite3 "$MENU_DB" "DELETE FROM menu WHERE id='$id';"; done
sqlite3 "$MENU_DB" "INSERT INTO menu(id,IdParent,Link,Name,Type,order_no) VALUES('busy_assistant','$PARENT','','Busy Assistant','module',90);"
sqlite3 "$MENU_DB" "INSERT INTO menu(id,IdParent,Link,Name,Type,order_no) VALUES('busy_dashboard','busy_assistant','','Dashboard','module',1);"
sqlite3 "$MENU_DB" "INSERT INTO menu(id,IdParent,Link,Name,Type,order_no) VALUES('busy_extensions','busy_assistant','','Extensions','module',2);"
sqlite3 "$MENU_DB" "INSERT INTO menu(id,IdParent,Link,Name,Type,order_no) VALUES('busy_calls','busy_assistant','','Calls Report','module',3);"
sqlite3 "$MENU_DB" "INSERT INTO menu(id,IdParent,Link,Name,Type,order_no) VALUES('busy_audio','busy_assistant','','Audio Manager','module',4);"
sqlite3 "$MENU_DB" "INSERT INTO menu(id,IdParent,Link,Name,Type,order_no) VALUES('busy_bale','busy_assistant','','Bale Settings','module',5);"
sqlite3 "$MENU_DB" "INSERT INTO menu(id,IdParent,Link,Name,Type,order_no) VALUES('busy_settings','busy_assistant','','Settings','module',6);"

say "Registering administrator ACL permissions"
ADMIN_GROUP="$(sqlite3 "$ACL_DB" "SELECT id FROM acl_group WHERE lower(name)='administrator' LIMIT 1;" 2>/dev/null || true)"
ADMIN_GROUP="${ADMIN_GROUP:-1}"
for id in busy_assistant busy_dashboard busy_extensions busy_calls busy_audio busy_bale busy_settings; do
    RID="$(sqlite3 "$ACL_DB" "SELECT id FROM acl_resource WHERE name='$id' LIMIT 1;" 2>/dev/null || true)"
    if [[ -z "$RID" ]]; then
        sqlite3 "$ACL_DB" "INSERT INTO acl_resource(name,description) VALUES('$id','Busy Assistant');"
        RID="$(sqlite3 "$ACL_DB" "SELECT id FROM acl_resource WHERE name='$id' LIMIT 1;")"
    fi
    EXISTS="$(sqlite3 "$ACL_DB" "SELECT id FROM acl_group_permission WHERE id_action=1 AND id_group=$ADMIN_GROUP AND id_resource=$RID LIMIT 1;" 2>/dev/null || true)"
    [[ -n "$EXISTS" ]] || sqlite3 "$ACL_DB" "INSERT INTO acl_group_permission(id_action,id_group,id_resource) VALUES(1,$ADMIN_GROUP,$RID);"
done

say "Importing Issabel extensions and generating queues"
/usr/local/sbin/busy-assistant-sync || say "Extension sync returned a warning. You can run it later with: busy-assistant-sync"

say "Validating installed code"
python3 -m py_compile "$AGI_DIR/busy_assistant.py" "$AGI_DIR/misscall_engine.py" /usr/local/sbin/busy-assistant-sync
if command -v php >/dev/null 2>&1; then
    while IFS= read -r -d '' f; do php -l "$f" >/dev/null || fail "PHP syntax error in $f"; done < <(find "$WEB_DIR/busy_assistant" "$WEB_DIR/busy_dashboard" "$WEB_DIR/busy_extensions" "$WEB_DIR/busy_calls" "$WEB_DIR/busy_audio" "$WEB_DIR/busy_bale" "$WEB_DIR/busy_settings" -name '*.php' -print0)
fi

say "Reloading Asterisk"
asterisk -rx "dialplan reload" >/dev/null || true
asterisk -rx "queue reload all" >/dev/null || asterisk -rx "core reload" >/dev/null || true
if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet httpd; then systemctl reload httpd || true; fi

say "Installation complete"
printf '%s\n' \
  "Panel: Busy Assistant -> Dashboard / Extensions / Calls Report / Audio Manager / Bale Settings / Settings" \
  "Database: $DB" \
  "AGI: $AGI_DIR" \
  "Backup: $BACKUP_DIR" \
  "Sync command: /usr/local/sbin/busy-assistant-sync"
if [[ -z "$(sqlite3 "$DB" "SELECT value FROM settings WHERE key='bale_token';")" ]]; then
    printf '%s\n' "Bale token is not configured. Enter it from Busy Assistant -> Bale Settings before testing notifications."
fi
printf '%s\n' "Upload the two prompts from Audio Manager before testing if custom/busy-assistant and custom/queue-wait do not already exist."
