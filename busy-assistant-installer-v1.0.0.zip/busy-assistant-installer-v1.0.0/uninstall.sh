#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Run as root" >&2; exit 1; }
DB=/opt/busy-assistant/data/busy.db
MENU_DB=/var/www/db/menu.db
ACL_DB=/var/www/db/acl.db

printf "Preserve Busy Assistant database and logs? [Y/n]: "
read -r PRESERVE || true
PRESERVE="${PRESERVE:-Y}"

remove_block(){
  local f="$1" begin="$2" end="$3"; [[ -f "$f" ]] || return 0
  python3 - "$f" "$begin" "$end" <<'PYBLOCK'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); t=p.read_text(encoding='utf-8',errors='ignore')
t=re.sub(re.escape(sys.argv[2])+r'.*?'+re.escape(sys.argv[3])+r'\n?', '', t, flags=re.S)
p.write_text(t.rstrip()+"\n",encoding='utf-8')
PYBLOCK
}
remove_block /etc/asterisk/extensions_override_issabel.conf '; BEGIN BUSY_ASSISTANT_INSTALLER' '; END BUSY_ASSISTANT_INSTALLER'
remove_block /etc/asterisk/extensions_custom.conf '; BEGIN BUSY_ASSISTANT_INSTALLER' '; END BUSY_ASSISTANT_INSTALLER'
remove_block /etc/asterisk/queues_custom.conf '; BEGIN BUSY_ASSISTANT_QUEUES' '; END BUSY_ASSISTANT_QUEUES'

if [[ -f "$MENU_DB" ]]; then for id in busy_settings busy_bale busy_audio busy_calls busy_extensions busy_dashboard busy_assistant; do sqlite3 "$MENU_DB" "DELETE FROM menu WHERE id='$id';"; done; fi
if [[ -f "$ACL_DB" ]]; then
  for id in busy_assistant busy_dashboard busy_extensions busy_calls busy_audio busy_bale busy_settings; do
    RID="$(sqlite3 "$ACL_DB" "SELECT id FROM acl_resource WHERE name='$id' LIMIT 1;" 2>/dev/null || true)"
    if [[ -n "$RID" ]]; then sqlite3 "$ACL_DB" "DELETE FROM acl_group_permission WHERE id_resource=$RID; DELETE FROM acl_user_permission WHERE id_resource=$RID; DELETE FROM acl_resource WHERE id=$RID;"; fi
  done
fi
rm -rf /var/lib/asterisk/agi-bin/busy-assistant
rm -f /usr/local/sbin/busy-assistant-sync
for m in busy_assistant busy_dashboard busy_extensions busy_calls busy_audio busy_bale busy_settings; do rm -rf "/var/www/html/modules/$m"; done
case "$PRESERVE" in n|N|no|NO) rm -rf /opt/busy-assistant;; esac
asterisk -rx "dialplan reload" >/dev/null 2>&1 || true
asterisk -rx "queue reload all" >/dev/null 2>&1 || true
if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet httpd; then systemctl reload httpd || true; fi
echo "Busy Assistant uninstalled. Existing /root/busy-assistant-backup-* backups were not removed."
