<?php
include_once "libs/paloSantoGrid.class.php";
include_once "libs/paloSantoForm.class.php";
include_once "libs/paloSantoConfig.class.php";
require_once "libs/misc.lib.php";

function _moduleContent(&$smarty, $module_name)
{
    include_once("modules/$module_name/configs/default.conf.php");
    include_once("/var/www/html/modules/busy_assistant/libs/BusyController.class.php");
    return busyController($smarty, "extensions");
}
?>
