<?php
function busyPageCalls()
{
    $db=busyDb(); $ext=busyGet('ext'); $caller=busyGet('caller'); $event=busyGet('event');
    $where=array(); $bind=array();
    if($ext!==''){ $where[]='extension=:e'; $bind[':e']=$ext; }
    if($caller!==''){ $where[]='caller LIKE :c'; $bind[':c']='%'.$caller.'%'; }
    if($event!==''){ $where[]='event=:ev'; $bind[':ev']=$event; }
    $sql='SELECT * FROM missed_calls'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY id DESC LIMIT 500';
    $st=$db->prepare($sql); foreach($bind as $k=>$v)$st->bindValue($k,$v,SQLITE3_TEXT); $rs=$st->execute();
    $body='<div class="ba-form"><form method="get"><input type="hidden" name="menu" value="busy_calls"><div class="ba-row"><div class="ba-field"><label>داخلی مقصد</label><input name="ext" value="'.busyH($ext).'"></div><div class="ba-field"><label>تماس‌گیرنده</label><input name="caller" value="'.busyH($caller).'"></div><div class="ba-field"><label>رویداد</label><select name="event"><option value="">همه</option>';
    foreach(array('NOANSWER','BUSY','USER_REJECT','QUEUE_TIMEOUT','QUEUE_HANGUP','TIMEOUT') as $ev)$body.='<option '.($event===$ev?'selected':'').' value="'.busyH($ev).'">'.busyH($ev).'</option>';
    $body.='</select></div></div><button class="ba-btn" type="submit">فیلتر</button></form></div><table class="ba-table"><tr><th>#</th><th>زمان</th><th>مقصد</th><th>تماس‌گیرنده</th><th>رویداد</th><th>Unique ID</th><th>بله</th></tr>';
    while($r=$rs->fetchArray(SQLITE3_ASSOC)) $body.='<tr><td>'.busyH($r['id']).'</td><td class="ba-ltr">'.busyH($r['created_at']).'</td><td>'.busyH($r['extension']).'</td><td class="ba-ltr">'.busyH($r['caller']).'</td><td>'.busyH($r['event']).'</td><td class="ba-ltr">'.busyH($r['uniqueid']).'</td><td>'.((int)$r['bale_sent']===1?'✓':'—').'</td></tr>';
    $body.='</table>';
    return busyLayout('گزارش تماس‌ها',$body);
}
?>