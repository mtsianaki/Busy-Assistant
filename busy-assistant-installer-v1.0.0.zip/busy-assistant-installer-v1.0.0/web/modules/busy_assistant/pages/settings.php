<?php
function busyPageSettings()
{
    $msg='';
    if($_SERVER['REQUEST_METHOD']==='POST'){
        busySetSetting('enabled',busyBoolPost('enabled')?'1':'0'); busySetSetting('default_timeout',(string)max(1,(int)busyPost('default_timeout','180'))); busySetSetting('notify_daily',busyBoolPost('notify_daily')?'1':'0');
        $msg=busyFlash('تنظیمات عمومی ذخیره شد.');
    }
    $enabled=busySetting('enabled','1')==='1';$timeout=busySetting('default_timeout','180');$daily=busySetting('notify_daily','0')==='1';
    $body=$msg.'<div class="ba-form"><form method="post"><div class="ba-row"><div class="ba-field"><label>Timeout پیش‌فرض صف (ثانیه)</label><input type="number" min="1" name="default_timeout" value="'.busyH($timeout).'"></div><div class="ba-field"><label><input type="checkbox" name="enabled" '.($enabled?'checked':'').'> فعال بودن کلی Busy Assistant</label><br><label><input type="checkbox" name="notify_daily" '.($daily?'checked':'').'> فعال بودن گزینه گزارش روزانه (رزرو برای توسعه)</label></div></div><button class="ba-btn good" type="submit">ذخیره</button></form></div><div class="ba-card"><h3>مسیرهای سیستم</h3><div class="ba-ltr"><code>/opt/busy-assistant/data/busy.db</code><br><code>/opt/busy-assistant/logs/busy-assistant.log</code><br><code>/var/lib/asterisk/agi-bin/busy-assistant/</code></div></div>';
    return busyLayout('تنظیمات عمومی',$body);
}
?>