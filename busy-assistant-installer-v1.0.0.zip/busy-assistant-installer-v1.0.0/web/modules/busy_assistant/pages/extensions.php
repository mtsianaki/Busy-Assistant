<?php
function busyPageExtensions()
{
    $db=busyDb(); $msg='';
    if ($_SERVER['REQUEST_METHOD']==='POST' && busyPost('action')==='save') {
        $ext=preg_replace('/\D+/','',busyPost('extension'));
        if ($ext==='' || strlen($ext)<3 || strlen($ext)>4) $msg=busyFlash('شماره داخلی باید ۳ یا ۴ رقم باشد.','err');
        else {
            $st=$db->prepare("INSERT INTO extensions(extension,name,bale_id,mobile,enabled,queue_timeout,created_at,updated_at) VALUES(:e,:n,:b,:m,:en,:q,datetime('now'),datetime('now')) ON CONFLICT(extension) DO UPDATE SET name=excluded.name,bale_id=excluded.bale_id,mobile=excluded.mobile,enabled=excluded.enabled,queue_timeout=excluded.queue_timeout,updated_at=excluded.updated_at");
            $st->bindValue(':e',$ext,SQLITE3_TEXT); $st->bindValue(':n',busyPost('name'),SQLITE3_TEXT); $st->bindValue(':b',busyPost('bale_id'),SQLITE3_TEXT); $st->bindValue(':m',busyPost('mobile'),SQLITE3_TEXT); $st->bindValue(':en',busyBoolPost('enabled'),SQLITE3_INTEGER); $st->bindValue(':q',max(1,(int)busyPost('queue_timeout','180')),SQLITE3_INTEGER); $st->execute();
            $msg=busyFlash('اطلاعات داخلی ذخیره شد. برای داخلی جدید، یک بار busy-assistant-sync را اجرا کنید تا صف آن ساخته شود.');
        }
    }
    if (busyGet('delete')!=='') {
        $st=$db->prepare('DELETE FROM extensions WHERE extension=:e'); $st->bindValue(':e',busyGet('delete'),SQLITE3_TEXT); $st->execute();
        $msg=busyFlash('داخلی حذف شد. برای حذف صف تولیدشده، busy-assistant-sync را اجرا کنید.');
    }
    $edit=array('extension'=>'','name'=>'','bale_id'=>'','mobile'=>'','enabled'=>1,'queue_timeout'=>(int)busySetting('default_timeout','180'));
    if (busyGet('edit')!=='') { $st=$db->prepare('SELECT * FROM extensions WHERE extension=:e'); $st->bindValue(':e',busyGet('edit'),SQLITE3_TEXT); $r=$st->execute()->fetchArray(SQLITE3_ASSOC); if($r)$edit=$r; }
    $body=$msg.'<div class="ba-form"><form method="post"><input type="hidden" name="action" value="save"><div class="ba-row"><div class="ba-field"><label>داخلی</label><input name="extension" type="text" value="'.busyH($edit['extension']).'" required></div><div class="ba-field"><label>نام</label><input name="name" type="text" value="'.busyH($edit['name']).'"></div><div class="ba-field"><label>Bale Chat ID</label><input name="bale_id" type="text" value="'.busyH($edit['bale_id']).'"></div></div><div class="ba-row"><div class="ba-field"><label>موبایل</label><input name="mobile" type="text" value="'.busyH($edit['mobile']).'"></div><div class="ba-field"><label>Timeout صف (ثانیه)</label><input name="queue_timeout" type="number" min="1" value="'.busyH($edit['queue_timeout']).'"></div><div class="ba-field"><label><input type="checkbox" name="enabled" '.((int)$edit['enabled']===1?'checked':'').'> فعال بودن منشی برای این داخلی</label></div></div><button class="ba-btn good" type="submit">ذخیره</button></form></div>';
    $body.='<table class="ba-table"><tr><th>داخلی</th><th>نام</th><th>Bale ID</th><th>موبایل</th><th>Timeout</th><th>وضعیت</th><th>عملیات</th></tr>';
    $rs=$db->query('SELECT * FROM extensions ORDER BY CAST(extension AS INTEGER),extension');
    while($r=$rs->fetchArray(SQLITE3_ASSOC)) $body.='<tr><td>'.busyH($r['extension']).'</td><td>'.busyH($r['name']).'</td><td class="ba-ltr">'.busyH($r['bale_id']).'</td><td class="ba-ltr">'.busyH($r['mobile']).'</td><td>'.busyH($r['queue_timeout']).'</td><td>'.((int)$r['enabled']===1?'<span class="ba-badge on">فعال</span>':'<span class="ba-badge off">غیرفعال</span>').'</td><td class="ba-actions"><a class="ba-btn" href="index.php?menu=busy_extensions&edit='.rawurlencode($r['extension']).'">ویرایش</a><a class="ba-btn danger" onclick="return confirm(\'حذف شود؟\')" href="index.php?menu=busy_extensions&delete='.rawurlencode($r['extension']).'">حذف</a></td></tr>';
    $body.='</table><p class="ba-muted">همگام‌سازی داخلی‌ها و صف‌ها از CLI: <code>sudo /usr/local/sbin/busy-assistant-sync</code></p>';
    return busyLayout('مدیریت داخلی‌ها',$body);
}
?>