<?php
function busyPageDashboard()
{
    $db=busyDb();
    $total=(int)$db->querySingle('SELECT COUNT(*) FROM extensions');
    $enabled=(int)$db->querySingle('SELECT COUNT(*) FROM extensions WHERE enabled=1');
    $today=(int)$db->querySingle("SELECT COUNT(*) FROM missed_calls WHERE substr(created_at,1,10)=date('now','localtime')");
    $sent=(int)$db->querySingle('SELECT COUNT(*) FROM missed_calls WHERE bale_sent=1');
    $token=busySetting('bale_token','');
    $body='<div class="ba-grid">';
    $cards=array('کل داخلی‌ها'=>$total,'منشی فعال'=>$enabled,'تماس از دست‌رفته امروز'=>$today,'پیام بله ارسال‌شده'=>$sent);
    foreach($cards as $k=>$v) $body.='<div class="ba-card"><div class="ba-muted">'.busyH($k).'</div><div class="ba-num">'.busyH($v).'</div></div>';
    $body.='</div>';
    $body.='<div class="ba-card"><b>وضعیت توکن بله:</b> '.($token?'<span class="ba-badge on">تنظیم شده</span>':'<span class="ba-badge off">تنظیم نشده</span>').' &nbsp; <b>وضعیت کلی:</b> '.(busySetting('enabled','1')==='1'?'<span class="ba-badge on">فعال</span>':'<span class="ba-badge off">غیرفعال</span>').'</div><br>';
    $body.='<h3>آخرین تماس‌های ثبت‌شده</h3><table class="ba-table"><tr><th>زمان</th><th>مقصد</th><th>تماس‌گیرنده</th><th>رویداد</th><th>بله</th></tr>';
    $rs=$db->query('SELECT * FROM missed_calls ORDER BY id DESC LIMIT 15');
    while($r=$rs->fetchArray(SQLITE3_ASSOC)){
        $body.='<tr><td class="ba-ltr">'.busyH($r['created_at']).'</td><td>'.busyH($r['extension']).'</td><td>'.busyH($r['caller']).'</td><td>'.busyH($r['event']).'</td><td>'.((int)$r['bale_sent']===1?'✓':'—').'</td></tr>';
    }
    $body.='</table>';
    return busyLayout('داشبورد Busy Assistant',$body);
}
?>