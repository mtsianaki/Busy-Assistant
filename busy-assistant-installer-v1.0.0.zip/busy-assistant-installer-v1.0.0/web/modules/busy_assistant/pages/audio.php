<?php
function busyAudioCurrent($base)
{
    $out=array(); foreach(array('wav','gsm','ulaw','alaw','sln','slin') as $x){$p=BUSY_ASSISTANT_AUDIO_CUSTOM.'/'.$base.'.'.$x;if(is_file($p))$out[]=basename($p);} return $out;
}
function busyPageAudio()
{
    $msg='';
    if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_FILES['audio'])) {
        $slot=busyPost('slot'); $map=array('assistant'=>'busy-assistant','queue'=>'queue-wait');
        if(!isset($map[$slot])) $msg=busyFlash('نوع فایل صوتی نامعتبر است.','err');
        elseif($_FILES['audio']['error']!==UPLOAD_ERR_OK) $msg=busyFlash('آپلود فایل ناموفق بود.','err');
        else {
            $ext=strtolower(pathinfo($_FILES['audio']['name'],PATHINFO_EXTENSION)); $ok=array('wav','gsm','ulaw','alaw','sln','slin');
            if(!in_array($ext,$ok,true)) $msg=busyFlash('فرمت مجاز: wav, gsm, ulaw, alaw, sln, slin','err');
            else {
                if(!is_dir(BUSY_ASSISTANT_AUDIO_CUSTOM)) @mkdir(BUSY_ASSISTANT_AUDIO_CUSTOM,0775,true);
                $target=BUSY_ASSISTANT_AUDIO_CUSTOM.'/'.$map[$slot].'.'.$ext;
                foreach($ok as $x){$old=BUSY_ASSISTANT_AUDIO_CUSTOM.'/'.$map[$slot].'.'.$x;if(is_file($old))@unlink($old);}
                if(move_uploaded_file($_FILES['audio']['tmp_name'],$target)){
                    @chmod($target,0644); $db=busyDb(); $st=$db->prepare("INSERT INTO audio_files(filename,description,enabled,created_at) VALUES(:f,:d,1,datetime('now')) ON CONFLICT(filename) DO UPDATE SET description=excluded.description,enabled=1"); $st->bindValue(':f',basename($target),SQLITE3_TEXT);$st->bindValue(':d',$slot,SQLITE3_TEXT);$st->execute();
                    $msg=busyFlash('فایل صوتی با موفقیت نصب شد.');
                } else $msg=busyFlash('امکان نوشتن در مسیر صدای Asterisk وجود ندارد. سطح دسترسی را بررسی کنید.','err');
            }
        }
    }
    $a=busyAudioCurrent('busy-assistant'); $q=busyAudioCurrent('queue-wait');
    $body=$msg.'<div class="ba-grid"><div class="ba-card"><h3>پیام اصلی منشی</h3><div class="ba-muted">Asterisk name: custom/busy-assistant</div><p>فایل فعلی: '.busyH($a?implode(', ',$a):'ندارد').'</p><form method="post" enctype="multipart/form-data"><input type="hidden" name="slot" value="assistant"><input type="file" name="audio" required> <button class="ba-btn" type="submit">آپلود/جایگزینی</button></form></div><div class="ba-card"><h3>پیام انتظار صف</h3><div class="ba-muted">Asterisk name: custom/queue-wait</div><p>فایل فعلی: '.busyH($q?implode(', ',$q):'ندارد').'</p><form method="post" enctype="multipart/form-data"><input type="hidden" name="slot" value="queue"><input type="file" name="audio" required> <button class="ba-btn" type="submit">آپلود/جایگزینی</button></form></div></div><p class="ba-muted">برای بیشترین سازگاری، WAV mono 8kHz یا فرمت‌های استاندارد Asterisk استفاده کنید.</p>';
    return busyLayout('مدیریت فایل‌های صوتی',$body);
}
?>