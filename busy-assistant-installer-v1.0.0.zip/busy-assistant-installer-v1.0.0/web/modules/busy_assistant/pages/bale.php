<?php
function busyBaleSendTest($token,$chat,$text)
{
    if(!$token || !$chat) return array(false,'Token or Chat ID is empty');
    $url='https://tapi.bale.ai/bot'.$token.'/sendMessage'; $data=http_build_query(array('chat_id'=>$chat,'text'=>$text));
    if(function_exists('curl_init')){ $ch=curl_init($url); curl_setopt($ch,CURLOPT_POST,true);curl_setopt($ch,CURLOPT_POSTFIELDS,$data);curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);curl_setopt($ch,CURLOPT_TIMEOUT,10);$r=curl_exec($ch);$e=curl_error($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);return array($r!==false && $code>=200 && $code<300,$e?:$r); }
    $ctx=stream_context_create(array('http'=>array('method'=>'POST','header'=>'Content-Type: application/x-www-form-urlencoded','content'=>$data,'timeout'=>10,'ignore_errors'=>true)));$r=@file_get_contents($url,false,$ctx);return array($r!==false,$r?:'HTTP request failed');
}
function busyPageBale()
{
    $msg='';
    if($_SERVER['REQUEST_METHOD']==='POST' && busyPost('action')==='save'){
        $token=busyPost('bale_token'); if($token!=='') busySetSetting('bale_token',$token);
        if(isset($_POST['clear_token'])) busySetSetting('bale_token','');
        busySetSetting('admin_chat_ids',busyPost('admin_chat_ids')); busySetSetting('notify_missed',busyBoolPost('notify_missed')?'1':'0');
        $msg=busyFlash('تنظیمات بله ذخیره شد.');
    }
    if($_SERVER['REQUEST_METHOD']==='POST' && busyPost('action')==='test'){
        $chat=busyPost('test_chat'); list($ok,$details)=busyBaleSendTest(busySetting('bale_token',''),$chat,'✅ Busy Assistant test message'); $msg=busyFlash($ok?'پیام تست با موفقیت ارسال شد.':'ارسال تست ناموفق بود: '.$details,$ok?'ok':'err');
    }
    $configured=busySetting('bale_token','')!==''; $admins=busySetting('admin_chat_ids',''); $notify=busySetting('notify_missed','1')==='1';
    $body=$msg.'<div class="ba-form"><form method="post"><input type="hidden" name="action" value="save"><div class="ba-row"><div class="ba-field"><label>توکن Bot بله</label><input type="password" name="bale_token" value="" placeholder="'.($configured?'توکن ذخیره شده؛ برای تغییر، مقدار جدید وارد کنید':'توکن را وارد کنید').'"><div class="ba-muted">توکن ذخیره‌شده در صفحه نمایش داده نمی‌شود.</div></div><div class="ba-field"><label>Admin Chat IDs (اختیاری)</label><textarea name="admin_chat_ids" placeholder="هر شناسه در یک خط">'.busyH($admins).'</textarea></div></div><label><input type="checkbox" name="notify_missed" '.($notify?'checked':'').'> ارسال اعلان تماس از دست‌رفته در بله</label><br><label><input type="checkbox" name="clear_token"> حذف توکن فعلی</label><br><br><button class="ba-btn good" type="submit">ذخیره تنظیمات</button></form></div><div class="ba-form"><form method="post"><input type="hidden" name="action" value="test"><div class="ba-field"><label>Chat ID برای تست</label><input type="text" name="test_chat" required></div><br><button class="ba-btn" type="submit">ارسال پیام تست</button></form></div>';
    return busyLayout('تنظیمات بله',$body);
}
?>