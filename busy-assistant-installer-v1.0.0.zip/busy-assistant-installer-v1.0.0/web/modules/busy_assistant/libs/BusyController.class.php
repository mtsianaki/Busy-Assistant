<?php
if (!defined('BUSY_ASSISTANT_DB')) define('BUSY_ASSISTANT_DB', '/opt/busy-assistant/data/busy.db');
if (!defined('BUSY_ASSISTANT_AUDIO_CUSTOM')) define('BUSY_ASSISTANT_AUDIO_CUSTOM', '/var/lib/asterisk/sounds/custom');

function busyDb()
{
    static $db = null;
    if ($db instanceof SQLite3) return $db;
    $db = new SQLite3(BUSY_ASSISTANT_DB);
    $db->busyTimeout(5000);
    return $db;
}

function busyH($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function busyPost($k, $d='') { return isset($_POST[$k]) ? trim((string)$_POST[$k]) : $d; }
function busyGet($k, $d='') { return isset($_GET[$k]) ? trim((string)$_GET[$k]) : $d; }
function busyBoolPost($k) { return isset($_POST[$k]) ? 1 : 0; }

function busySetting($key, $default='')
{
    $st = busyDb()->prepare('SELECT value FROM settings WHERE key=:k LIMIT 1');
    $st->bindValue(':k', $key, SQLITE3_TEXT);
    $r = $st->execute()->fetchArray(SQLITE3_ASSOC);
    return $r ? (string)$r['value'] : $default;
}

function busySetSetting($key, $value)
{
    $st = busyDb()->prepare("INSERT INTO settings(key,value,updated_at) VALUES(:k,:v,datetime('now')) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at");
    $st->bindValue(':k', $key, SQLITE3_TEXT);
    $st->bindValue(':v', $value, SQLITE3_TEXT);
    return (bool)$st->execute();
}

function busyFlash($text, $type='ok')
{
    return '<div class="ba-flash ba-'.busyH($type).'">'.busyH($text).'</div>';
}

function busyLayout($title, $body)
{
    $css = '<style>
    .ba{font-family:Tahoma,Arial,sans-serif;direction:rtl;text-align:right;color:#20242b;padding:8px 10px 25px}
    .ba h2{margin:6px 0 18px;font-size:22px}.ba h3{margin:0 0 12px}.ba a{color:#1557a0;text-decoration:none}
    .ba-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:12px 0 20px}
    .ba-card{background:#fff;border:1px solid #dfe3e8;border-radius:8px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,.04)}
    .ba-num{font-size:28px;font-weight:bold;margin-top:7px}.ba-muted{color:#68717d;font-size:12px}
    .ba-table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #dfe3e8}.ba-table th,.ba-table td{border-bottom:1px solid #e8ebef;padding:9px 8px;text-align:right;vertical-align:middle}.ba-table th{background:#f4f6f8}.ba-table tr:hover td{background:#fafbfd}
    .ba-form{background:#fff;border:1px solid #dfe3e8;border-radius:8px;padding:16px;margin:10px 0 18px}.ba-row{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:10px}.ba-field{min-width:180px;flex:1}.ba-field label{display:block;font-weight:bold;margin-bottom:5px}.ba input[type=text],.ba input[type=password],.ba input[type=number],.ba textarea,.ba select{width:100%;box-sizing:border-box;border:1px solid #cbd2da;border-radius:4px;padding:8px;background:#fff}.ba textarea{min-height:85px}.ba-btn{display:inline-block;border:0;border-radius:4px;padding:8px 14px;background:#265f9e;color:#fff!important;cursor:pointer;margin:2px}.ba-btn.secondary{background:#68717d}.ba-btn.danger{background:#a83232}.ba-btn.good{background:#277b45}.ba-flash{padding:10px 12px;border-radius:5px;margin:8px 0 14px}.ba-ok{background:#e8f6ed;color:#176132}.ba-err{background:#fdecec;color:#8e2525}.ba-warn{background:#fff5da;color:#755a14}.ba-badge{display:inline-block;padding:3px 7px;border-radius:12px;background:#eef2f6;font-size:11px}.ba-badge.on{background:#e4f5e9;color:#176132}.ba-badge.off{background:#f7e8e8;color:#8e2525}.ba-ltr{direction:ltr;text-align:left}.ba-actions{white-space:nowrap}
    </style>';
    return $css.'<div class="ba"><h2>'.busyH($title).'</h2>'.$body.'</div>';
}

function busyController(&$smarty, $action)
{
    $allowed = array('dashboard','extensions','calls','audio','bale','settings');
    if (!in_array($action, $allowed, true)) $action = 'dashboard';
    $file = '/var/www/html/modules/busy_assistant/pages/'.$action.'.php';
    if (!is_file($file)) return busyLayout('Busy Assistant', busyFlash('Page not found', 'err'));
    include_once $file;
    $fn = 'busyPage'.ucfirst($action);
    if (!function_exists($fn)) return busyLayout('Busy Assistant', busyFlash('Page handler not found', 'err'));
    return $fn();
}
?>
