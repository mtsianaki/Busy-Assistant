<?php
global $arrConf;
$arrConf['basePath'] = realpath(dirname(__FILE__).'/..');
?>
