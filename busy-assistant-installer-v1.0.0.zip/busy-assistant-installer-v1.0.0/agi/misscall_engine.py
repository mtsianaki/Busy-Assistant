#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import datetime
import sqlite3
import urllib.request
import urllib.parse

DB = "/opt/busy-assistant/data/busy.db"
LOG = "/opt/busy-assistant/logs/busy-assistant.log"


def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("{} {}\n".format(datetime.datetime.now(), msg))
    except Exception:
        pass


def read_headers():
    data = {}
    while True:
        line = sys.stdin.readline().strip()
        if line == "":
            break
        if ":" in line:
            k, v = line.split(":", 1)
            data[k.strip()] = v.strip()
    return data


def agi(cmd):
    print(cmd)
    sys.stdout.flush()
    result = sys.stdin.readline().strip()
    log("CMD={} RESPONSE={}".format(cmd, result))
    return result


def get_var(name, headers):
    result = agi("GET VARIABLE {}".format(name))
    if "result=" in result:
        value = result.split("result=", 1)[1].strip()
        if "(" in value:
            value = value.split("(", 1)[1].replace(")", "")
        if value:
            return value.strip()
    mapping = {
        "CALLERID(num)": "agi_callerid",
        "CALLERID(name)": "agi_calleridname",
        "EXTTOCALL": "agi_extension",
        "MISSED_EVENT": "agi_event",
        "BUSY_EVENT": "agi_event",
        "UNIQUEID": "agi_uniqueid",
        "ANSWEREDTIME": "agi_answeredtime",
        "DIALSTATUS": "agi_dialstatus",
    }
    return headers.get(mapping.get(name, ""), "")


def get_setting(key, default=""):
    try:
        conn = sqlite3.connect(DB, timeout=5)
        cur = conn.cursor()
        cur.execute("SELECT value FROM settings WHERE key=? LIMIT 1", (key,))
        row = cur.fetchone()
        conn.close()
        if row is not None and row[0] is not None:
            return str(row[0]).strip()
    except Exception as e:
        log("DB SETTING ERROR key={} error={}".format(key, e))
    return default


def setting_bool(key, default=True):
    raw = get_setting(key, "1" if default else "0").lower()
    return raw in ("1", "yes", "true", "on", "enabled")


def get_destination_info(ext):
    conn = sqlite3.connect(DB, timeout=5)
    cur = conn.cursor()
    cur.execute("SELECT name, bale_id FROM extensions WHERE extension=?", (ext,))
    row = cur.fetchone()
    conn.close()
    return row


def get_caller_name(caller):
    if not caller:
        return ""
    conn = sqlite3.connect(DB, timeout=5)
    cur = conn.cursor()
    cur.execute("SELECT name FROM extensions WHERE extension=?", (caller,))
    row = cur.fetchone()
    conn.close()
    if row and row[0]:
        return str(row[0]).strip()
    return ""


def already_sent(uniqueid):
    if not uniqueid:
        return False
    conn = sqlite3.connect(DB, timeout=5)
    cur = conn.cursor()
    cur.execute("SELECT id FROM missed_calls WHERE uniqueid=? AND bale_sent=1", (uniqueid,))
    row = cur.fetchone()
    conn.close()
    return row is not None


def save_event(ext, caller, event, uniqueid):
    conn = sqlite3.connect(DB, timeout=5)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO missed_calls(extension,caller,event,uniqueid,created_at,bale_sent) VALUES(?,?,?,?,?,0)",
        (ext, caller, event, uniqueid, datetime.datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()


def mark_sent(uniqueid):
    if not uniqueid:
        return
    conn = sqlite3.connect(DB, timeout=5)
    cur = conn.cursor()
    cur.execute("UPDATE missed_calls SET bale_sent=1 WHERE uniqueid=?", (uniqueid,))
    conn.commit()
    conn.close()


def event_text(event):
    data = {
        "QUEUE_TIMEOUT": "⏳ تماس‌گیرنده پس از انتظار در صف پاسخ دریافت نکرد.",
        "TIMEOUT": "⏳ زمان انتظار صف تمام شد.",
        "QUEUE_HANGUP": "☎️ تماس‌گیرنده هنگام انتظار تماس را قطع کرد.",
        "USER_REJECT": "ℹ️ تماس‌گیرنده وارد صف انتظار نشد.",
        "BUSY": "🔴 داخلی هنگام تماس مشغول بود.",
        "NOANSWER": "📵 داخلی پاسخگو نبود.",
    }
    return data.get(event, "📌 تماس بدون پاسخ ثبت شد.")


def send_bale(chat_id, text):
    token = get_setting("bale_token", "")
    if not token:
        log("BALE TOKEN NOT CONFIGURED")
        return False
    url = "https://tapi.bale.ai/bot{}/sendMessage".format(token)
    data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
    try:
        req = urllib.request.Request(url, data=data)
        response = urllib.request.urlopen(req, timeout=10).read().decode()
        log("BALE RESPONSE {}".format(response))
        return True
    except Exception as e:
        log("BALE ERROR {}".format(e))
        return False


def main():
    headers = read_headers()
    log("==============================")
    log("MISSCALL ENGINE START")

    caller = get_var("CALLERID(num)", headers)
    caller_id_name = get_var("CALLERID(name)", headers)
    ext = get_var("EXTTOCALL", headers)
    event = get_var("MISSED_EVENT", headers)
    if event in ("", "0"):
        event = get_var("BUSY_EVENT", headers)
    uniqueid = get_var("UNIQUEID", headers)
    answered = get_var("ANSWEREDTIME", headers)
    dialstatus = get_var("DIALSTATUS", headers)
    if event in ("", "0"):
        event = "NOANSWER"

    log("CALLER={} CALLER_NAME={} EXT={} EVENT={} UNIQUEID={} ANSWERED={} STATUS={}".format(
        caller, caller_id_name, ext, event, uniqueid, answered, dialstatus
    ))

    if answered and answered != "0" and event not in (
        "TIMEOUT", "QUEUE_TIMEOUT", "QUEUE_HANGUP", "USER_REJECT", "BUSY"
    ):
        log("CALL ANSWERED - SKIP BALE")
        return
    if not ext:
        log("NO EXTENSION")
        return
    if already_sent(uniqueid):
        log("DUPLICATE - SKIP")
        return

    save_event(ext, caller, event, uniqueid)
    info = get_destination_info(ext)
    if not info:
        log("NO DB RECORD {}".format(ext))
        return
    destination_name, bale_id = info
    if not bale_id:
        log("NO BALE ID")
        return

    if not setting_bool("notify_missed", True):
        log("BALE MISSED-CALL NOTIFICATIONS DISABLED")
        return

    caller_name = get_caller_name(caller)
    if not caller_name:
        caller_name = caller_id_name
    if (
        not caller_name
        or caller_name == caller
        or caller_name == "<unknown>"
        or caller_name.lower() == "unknown"
    ):
        caller_name = "نامشخص"

    log("DESTINATION={} DESTINATION_NAME={} CALLER={} CALLER_NAME={} BALE_ID={}".format(
        ext, destination_name, caller, caller_name, bale_id
    ))

    message = """
📞🔔 تماس از دست رفته

👤 داخلی مقصد:
{}

🧑 نام تماس‌گیرنده:
{}

📱 شماره تماس‌گیرنده:
{}

📌 وضعیت:
{}

🕒 زمان:
{}
""".format(
        ext,
        caller_name,
        caller,
        event_text(event),
        datetime.datetime.now().strftime("%H:%M:%S"),
    )

    if send_bale(bale_id, message):
        mark_sent(uniqueid)

    log("MISSCALL ENGINE END")
    log("==============================")


if __name__ == "__main__":
    main()
