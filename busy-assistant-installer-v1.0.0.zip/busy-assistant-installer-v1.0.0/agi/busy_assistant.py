#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import datetime
import sqlite3

LOG = "/opt/busy-assistant/logs/busy-assistant.log"
DB = "/opt/busy-assistant/data/busy.db"
DEFAULT_TIMEOUT = 180


def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("{} {}\n".format(datetime.datetime.now(), msg))
    except Exception:
        pass


def read_agi_headers():
    data = {}
    while True:
        line = sys.stdin.readline().strip()
        if line == "":
            break
        if ":" in line:
            key, value = line.split(":", 1)
            data[key.strip()] = value.strip()
    return data


def agi_command(command):
    print(command)
    sys.stdout.flush()
    response = sys.stdin.readline().strip()
    log("CMD={} RESPONSE={}".format(command, response))
    return response


def get_variable(name):
    result = agi_command("GET VARIABLE {}".format(name))
    if "result=" in result:
        value = result.split("result=", 1)[1].strip()
        if "(" in value:
            value = value.split("(", 1)[1].replace(")", "")
        return value.strip()
    return ""


def set_variable(name, value):
    if not name.startswith("__"):
        name = "__" + name
    agi_command("SET VARIABLE {} {}".format(name, value))


def normalize_ext(ext):
    if not ext:
        return ""
    ext = ext.strip().replace("SIP/", "").replace("PJSIP/", "")
    if "@" in ext:
        ext = ext.split("@", 1)[0]
    return ext


def is_internal(ext):
    ext = normalize_ext(ext)
    return bool(ext and ext.isdigit() and 3 <= len(ext) <= 4)


def get_setting(key, default=""):
    try:
        conn = sqlite3.connect(DB, timeout=5)
        cur = conn.cursor()
        cur.execute("SELECT value FROM settings WHERE key=? LIMIT 1", (key,))
        row = cur.fetchone()
        conn.close()
        if row is not None and row[0] is not None:
            return str(row[0]).strip()
    except Exception as e:
        log("DB SETTING ERROR key={} error={}".format(key, e))
    return default


def setting_bool(key, default=True):
    raw = get_setting(key, "1" if default else "0").lower()
    return raw in ("1", "yes", "true", "on", "enabled")


def get_extension_config(ext):
    try:
        default_timeout = int(get_setting("default_timeout", str(DEFAULT_TIMEOUT)) or DEFAULT_TIMEOUT)
    except Exception:
        default_timeout = DEFAULT_TIMEOUT
    config = {"found": False, "enabled": True, "queue_timeout": default_timeout}
    try:
        conn = sqlite3.connect(DB, timeout=5)
        cur = conn.cursor()
        cur.execute(
            "SELECT enabled, queue_timeout FROM extensions WHERE extension=? LIMIT 1",
            (ext,),
        )
        row = cur.fetchone()
        conn.close()
        if not row:
            log("DB EXTENSION NOT FOUND ext={} - USE DEFAULTS".format(ext))
            return config
        config["found"] = True
        try:
            config["enabled"] = int(row[0] if row[0] is not None else 1) == 1
        except Exception:
            config["enabled"] = True
        try:
            timeout = int(row[1])
            if timeout > 0:
                config["queue_timeout"] = timeout
        except Exception:
            pass
        return config
    except Exception as e:
        log("DB CONFIG ERROR ext={} error={}".format(ext, e))
        return config


def main():
    read_agi_headers()
    log("==============================")
    log("BUSY ASSISTANT START")

    caller = get_variable("CALLERID(num)")
    raw_ext = get_variable("EXTTOCALL")
    ext = normalize_ext(raw_ext)
    status = get_variable("DIALSTATUS")
    log("CALLER={} RAW_EXT={} EXT={} STATUS={}".format(caller, raw_ext, ext, status))

    if not is_internal(ext):
        log("NOT INTERNAL - SKIP RAW={}".format(raw_ext))
        return

    if not setting_bool("enabled", True):
        log("BUSY ASSISTANT GLOBALLY DISABLED")
        return

    config = get_extension_config(ext)
    enabled = config["enabled"]
    queue_timeout = config["queue_timeout"]
    log("PANEL CONFIG EXT={} FOUND={} ENABLED={} QUEUE_TIMEOUT={}".format(
        ext, config["found"], enabled, queue_timeout
    ))

    if not enabled:
        log("BUSY ASSISTANT DISABLED FOR EXT={}".format(ext))
        return

    set_variable("BUSY_NOTIFY", "NO")

    log("ANSWER CHANNEL FOR BUSY ASSISTANT")
    answer_result = agi_command("ANSWER")
    log("ANSWER RESULT={}".format(answer_result))

    dtmf = agi_command("GET DATA custom/busy-assistant 5000 1")
    log("DTMF={}".format(dtmf))

    if "result=1" not in dtmf:
        log("USER REJECT QUEUE")
        set_variable("MISSED_EVENT", "USER_REJECT")
        set_variable("BUSY_NOTIFY", "YES")
        return

    queue_number = "9" + ext
    log("ENTER QUEUE {}".format(queue_number))
    set_variable("BUSY_ASSISTANT_QUEUE", "YES")
    set_variable("BUSY_QUEUE_EXT", ext)

    agi_command('STREAM FILE custom/queue-wait ""')
    log("START QUEUE {} TIMEOUT {}".format(queue_number, queue_timeout))
    agi_command("EXEC Queue {},,,,{}".format(queue_number, queue_timeout))
    queue_status = get_variable("QUEUESTATUS")
    log("QUEUESTATUS={}".format(queue_status))

    if queue_status == "COMPLETE":
        log("QUEUE ANSWERED")
        set_variable("BUSY_NOTIFY", "NO")
        agi_command("HANGUP")
    else:
        log("QUEUE FAILED {}".format(queue_status))
        if queue_status in ("TIMEOUT", "ABANDON", "FULL", "JOINEMPTY", "LEAVEEMPTY", ""):
            event = "QUEUE_TIMEOUT"
        else:
            event = queue_status
        set_variable("MISSED_EVENT", event)
        set_variable("BUSY_NOTIFY", "YES")

    log("BUSY ASSISTANT END")
    log("==============================")


if __name__ == "__main__":
    main()
