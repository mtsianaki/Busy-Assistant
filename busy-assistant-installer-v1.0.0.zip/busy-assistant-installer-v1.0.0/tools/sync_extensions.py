#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import datetime
import re
import sqlite3
import subprocess
from pathlib import Path

DB = "/opt/busy-assistant/data/busy.db"
QUEUES = "/etc/asterisk/queues_custom.conf"
BEGIN = "; BEGIN BUSY_ASSISTANT_QUEUES"
END = "; END BUSY_ASSISTANT_QUEUES"


def run(cmd):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=False).stdout


def astdb_value(family, key):
    out = run(["asterisk", "-rx", "database get {} {}".format(family, key)])
    m = re.search(r"Value:\s*(.+)", out)
    return m.group(1).strip() if m else ""


def discover_extensions():
    out = run(["asterisk", "-rx", "database show AMPUSER"])
    found = {}
    for line in out.splitlines():
        m = re.search(r"/AMPUSER/(\d{3,4})/cidname\s*:\s*(.*)$", line)
        if m:
            found[m.group(1)] = m.group(2).strip()
    return found


def ensure_schema(conn):
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS extensions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        extension TEXT UNIQUE NOT NULL,
        name TEXT,
        bale_id TEXT,
        enabled INTEGER DEFAULT 0,
        queue_timeout INTEGER DEFAULT 180,
        created_at TEXT,
        updated_at TEXT,
        mobile TEXT
    );
    """)


def sync_db(enable_new=False):
    items = discover_extensions()
    conn = sqlite3.connect(DB)
    ensure_schema(conn)
    now = datetime.datetime.now().isoformat()
    for ext, name in sorted(items.items()):
        row = conn.execute("SELECT id FROM extensions WHERE extension=?", (ext,)).fetchone()
        if row:
            conn.execute("UPDATE extensions SET name=COALESCE(NULLIF(?,''),name),updated_at=? WHERE extension=?", (name, now, ext))
        else:
            conn.execute(
                "INSERT INTO extensions(extension,name,enabled,queue_timeout,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                (ext, name, 1 if enable_new else 0, 180, now, now),
            )
    conn.commit()
    rows = conn.execute("SELECT extension,name FROM extensions ORDER BY CAST(extension AS INTEGER)").fetchall()
    conn.close()
    return items, rows


def replace_marked(text, block):
    pattern = re.compile(re.escape(BEGIN) + r".*?" + re.escape(END) + r"\n?", re.S)
    text = pattern.sub("", text).rstrip() + "\n\n"
    return text + block.rstrip() + "\n"


def generate_queues(rows):
    blocks = [BEGIN]
    for ext, name in rows:
        dial = astdb_value("DEVICE", "{}/dial".format(ext)) or "SIP/{}".format(ext)
        dial = dial.split("&", 1)[0].strip()
        q = "9" + ext
        blocks += [
            "[{}]".format(q),
            "strategy=ringall",
            "timeout=15",
            "retry=2",
            "wrapuptime=0",
            "maxlen=1",
            "joinempty=yes",
            "leavewhenempty=no",
            "ringinuse=no",
            "member => {}".format(dial),
            "",
        ]
    blocks.append(END)
    path = Path(QUEUES)
    old = path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""
    path.write_text(replace_marked(old, "\n".join(blocks)), encoding="utf-8")


def main():
    p = argparse.ArgumentParser(description="Sync Issabel extensions and Busy Assistant queues")
    p.add_argument("--enable-new", action="store_true", help="Enable newly imported extensions")
    p.add_argument("--no-queues", action="store_true", help="Do not update queues_custom.conf")
    args = p.parse_args()
    discovered, rows = sync_db(args.enable_new)
    print("Discovered {} extension(s), database now has {} extension(s).".format(len(discovered), len(rows)))
    if not args.no_queues:
        generate_queues(rows)
        print("Updated {}".format(QUEUES))
        run(["asterisk", "-rx", "queue reload all"])


if __name__ == "__main__":
    main()
