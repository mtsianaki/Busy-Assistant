PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT
);

CREATE TABLE IF NOT EXISTS extensions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    extension TEXT UNIQUE NOT NULL,
    name TEXT,
    bale_id TEXT,
    enabled INTEGER DEFAULT 0,
    queue_timeout INTEGER DEFAULT 180,
    created_at TEXT,
    updated_at TEXT,
    mobile TEXT
);

CREATE TABLE IF NOT EXISTS missed_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    extension TEXT,
    caller TEXT,
    event TEXT,
    uniqueid TEXT,
    created_at TEXT,
    bale_sent INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_missed_uniqueid ON missed_calls(uniqueid);
CREATE INDEX IF NOT EXISTS idx_missed_extension ON missed_calls(extension);
CREATE INDEX IF NOT EXISTS idx_missed_created_at ON missed_calls(created_at);

CREATE TABLE IF NOT EXISTS audio_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT UNIQUE NOT NULL,
    description TEXT,
    enabled INTEGER DEFAULT 1,
    created_at TEXT
);

INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('bale_token','',datetime('now'));
INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('admin_chat_ids','',datetime('now'));
INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('default_timeout','180',datetime('now'));
INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('enabled','1',datetime('now'));
INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('notify_missed','1',datetime('now'));
INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('notify_daily','0',datetime('now'));
INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('audio_path','/var/lib/asterisk/sounds/custom/',datetime('now'));
