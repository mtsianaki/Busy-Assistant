# Busy Assistant Installer v1.0.0

Complete installer for an Issabel/Asterisk Busy Assistant and missed-call notification system.

## Included

- `busy_assistant.py` AGI: busy/no-answer assistant, DTMF 1, per-extension queue and timeout.
- `misscall_engine.py` AGI: missed-call logging and Bale notifications.
- SQLite database schema.
- Issabel web panel with Dashboard, Extensions, Calls Report, Audio Manager, Bale Settings and Settings.
- Asterisk dialplan hooks.
- Automatic import of Issabel extensions and generation of queue `9<extension>` for every extension.
- Uninstaller.

## Security / portability

No organization-specific Bale token, password, phone number, domain or Chat ID is included. The Bale token is stored in `/opt/busy-assistant/data/busy.db` and can be entered either during installation or later from **Busy Assistant -> Bale Settings**. The web panel never displays the saved token back in clear text.

## Requirements

- Issabel with Asterisk 18-compatible dialplan/AGI behavior.
- Rocky Linux / RHEL-family environment used by Issabel.
- `python3`, `sqlite3`, `asterisk` CLI.
- PHP with SQLite3 support for the management panel.
- Root access for installation.

## Installation

```bash
unzip busy-assistant-installer-v1.0.0.zip
cd busy-assistant-installer-v1.0.0
chmod +x install.sh
sudo ./install.sh
```

The installer:

1. creates a backup under `/root/busy-assistant-backup-YYYYMMDD-HHMMSS`;
2. creates/migrates `busy.db`;
3. optionally asks for the Bale token, admin Chat IDs and default queue timeout;
4. installs AGI files and the web modules;
5. imports Issabel extensions;
6. generates queues `9<extension>` in `/etc/asterisk/queues_custom.conf`;
7. installs dialplan hooks using identifiable BEGIN/END markers;
8. registers Issabel menu/ACL resources;
9. validates Python/PHP syntax and reloads Asterisk.

## First configuration

Open **Busy Assistant** in Issabel:

- **Extensions**: enable the desired extensions, enter each owner's Bale Chat ID and queue timeout.
- **Audio Manager**: upload `busy-assistant` and `queue-wait` prompts. WAV mono/8kHz is recommended.
- **Bale Settings**: enter the bot token and optionally send a test message.
- **Settings**: global enable/disable and default timeout.

Newly imported extensions are disabled by default for safety. Enable them from the panel.

## Extension / queue sync

After adding or removing extensions in Issabel, run:

```bash
sudo /usr/local/sbin/busy-assistant-sync
```

To automatically enable newly imported extensions:

```bash
sudo /usr/local/sbin/busy-assistant-sync --enable-new
```

## Important paths

- Database: `/opt/busy-assistant/data/busy.db`
- Log: `/opt/busy-assistant/logs/busy-assistant.log`
- AGIs: `/var/lib/asterisk/agi-bin/busy-assistant/`
- Web modules: `/var/www/html/modules/busy_*`
- Prompts: `/var/lib/asterisk/sounds/custom/busy-assistant.*` and `queue-wait.*`

## Diagnostics

```bash
tail -f /opt/busy-assistant/logs/busy-assistant.log
asterisk -rvvv
asterisk -rx "dialplan show macro-exten-vm"
asterisk -rx "queue show 9130"
sqlite3 /opt/busy-assistant/data/busy.db "SELECT extension,name,enabled,queue_timeout,bale_id FROM extensions ORDER BY extension;"
```

## Uninstall

```bash
sudo ./uninstall.sh
```

The uninstaller asks whether to preserve the SQLite database and logs. Installer backups under `/root/busy-assistant-backup-*` are never deleted automatically.

## Notes

The installer edits Asterisk custom/override files only inside clearly marked Busy Assistant blocks. It also backs up the affected files before changes. If the target Issabel installation has heavily customized `h` extensions or `macro-exten-vm` overrides, review the generated dialplan after installation before production use.
